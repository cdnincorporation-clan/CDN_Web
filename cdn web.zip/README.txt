CDN - Cartel Del Norte (Simple Web Landing)
==========================================

Archivos incluidos:
- index.html
- style.css
- script.js
- /images/logo.png

Instrucciones rápidas:
1. Descomprime el archivo.
2. Abre index.html en tu navegador para ver la página localmente.
3. Para publicar: sube los archivos a GitHub Pages, Netlify o cualquier hosting estático.

Personalización:
- Cambia images/logo.png por otra imagen si lo deseas.
- Ajusta el enlace DISCORD en script.js.
- Para cambiar colores o intensidad del efecto neón, edita style.css.

Generado por: ChatGPT (CDN Web package)
